# ======================================
# CONFIGURACIÓN DEL PROYECTO
# ======================================

ruta_stockfish <- "stockfish.exe"   # cambiar solo si está en otra ruta

profundidad_stockfish <- 10
tiempo_stockfish_ms <- 200

# POSICIÓN INICIAL CORRECTA EN FEN
fen_inicial <- "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
